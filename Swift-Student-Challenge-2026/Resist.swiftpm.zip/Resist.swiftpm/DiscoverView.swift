import SwiftUI

struct DiscoverView: View {
    var body: some View {
        ZStack {
            Color.mint.opacity(0.1)
                .ignoresSafeArea()
            ScrollView {
                VStack {
                    contentStack
                        Text("Information might not be accurate")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("Always consult a professional")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.bottom, 10)
                }
            }
        }
    }
    
    private var contentStack: some View {
        VStack(alignment: .leading, spacing: 8) {
            VStack(alignment: .leading, spacing: 12) {
                Label("What is OCD?", systemImage:  "info.circle.text.page")
                    .font(.title)
                Text("OCD stands for 'Obsessive Compulsive Disorder'.")
                    .bold()
                Text("It's a disorder in which people get involuntary, intrusive thoughts, images, or even urges that lead to compulsions.")
                
                Divider()
                Text("Example:")
                Text("One may get thoughts about the doorknob being contaminated with germs, leading them to wash their hands when coming in contact with doorknob.")
                    .font(.footnote)
            }
            .padding()
            .background(Color.mint.opacity(0.2))
            .clipShape(RoundedRectangle(cornerRadius: 12))
                
            VStack(alignment: .leading, spacing: 12) {
                Label("Treatment", systemImage: "bandage")
                    .font(.title)
                    
                Text("Exposure Response Prevention (ERP)")
                    .font(.title2)
                Text("ERP is one of the most effective treatments. The goal is to face the thought without performing the compulsion.")
                    .bold()
                    .accessibilityLabel("E. R. P. is one of the most effective treatments. The goal is to face the thought without performing the compulsion.")
                Divider()
                Text("Whenever you get the thought: ")
                Label("Calm down by breathing slowly with the circle", systemImage: "circle.dotted.circle")
                Label("If you successfully resisted, press the 'I Resisted' button", systemImage: "hand.tap")
                
            }
            .padding()
            .background(Color.mint.opacity(0.2))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .padding()
    }
}

#Preview {
    DiscoverView()
}

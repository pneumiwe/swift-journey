import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    
    var body: some View {
        TabView(selection: $selection) {
            Tab("Calm Down", systemImage: "circle.dotted.circle", value: 0) {
                CalmDownView()
            }
            Tab("Resist", systemImage: "hand.tap", value: 1) {
                ResistView()
            }
            Tab("Discover", systemImage: "lightbulb.max", value: 3) {
                DiscoverView()
            }
        }
    }
}

#Preview {
    ContentView()
}

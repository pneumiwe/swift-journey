import Foundation

enum Milestones: Codable, CaseIterable {
    case firstResist
    case fiveResists
    case tenResists
    case twentyFiveResists
    case fiftyResists
    case hundredResists
    
    var threshold: Int {
        switch self {
        case .firstResist: return 1
        case .fiveResists: return 5
        case .tenResists: return 10
        case .twentyFiveResists: return 25
        case .fiftyResists: return 50
        case .hundredResists: return 100
        }
    }
    
    var congratulatoryMessage: String {
        switch self {
        case .firstResist:
            return "Congratulations on your first resist!"
            
        case .fiveResists: 
            return "Keep going! Resisting urges is a great way to treat OCD."
            
        case .tenResists: 
            return "10 Resists! Keep going and you'll see results in no time!"
            
        case .twentyFiveResists:
            return "You're halway to 50! You can do it!"
            
        case .fiftyResists:
            return "50 resists is no joke. Celebrate your milestone, you earned it!"
            
        case .hundredResists:
            return "You did it! How do you feel now compared to when you started this journey?"
        }
    }
    
    static func milestone(for count: Int) -> (previous: Int, next: Int, nextDetails: Milestones?) {
        
        let sorted = Milestones.allCases.sorted { $0.threshold < $1.threshold }
        
        var previous = 0
        
        for details in sorted {
            if count < details.threshold {
                return (previous, details.threshold, details)
            }
            previous = details.threshold
        }
        
        return (previous, previous, nil)
    }
    
    static func progressSegment(for count: Int) -> (previous: Int, next: Int) {
        let thresholds = Milestones.allCases
            .map { $0.threshold }
            .sorted()
        
        var previous = 0
        
        for threshold in thresholds {
            if count <= threshold {
                return (previous, threshold)
            }
            previous = threshold
        }
        
        return (previous, previous)
    }
}


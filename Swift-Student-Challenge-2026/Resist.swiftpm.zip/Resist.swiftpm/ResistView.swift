import SwiftUI
import UIKit

struct ResistView: View {
    @AppStorage("resistCount") private var resistCount: Int = 0
    
    @State private var pulse = false
    @State private var showCelebration = false
    
    @AccessibilityFocusState private var isCelebrationFocused: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        ZStack {
            Color.mint.opacity(0.1)
                .ignoresSafeArea()
            contentStack
        }
    }
    
    private var contentStack: some View {
        VStack {
            let milestone = Milestones.milestone(for: resistCount)
            let segment = Milestones.progressSegment(for: resistCount)
            let segmentProgress: Double = {
                if segment.next == segment.previous {
                    return 1.0
                }
                
                let raw = Double(resistCount - segment.previous) / Double(segment.next - segment.previous)
                return min(max(raw, 0), 1)
            }()
            
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.3), lineWidth: 20)
                
                Circle()
                    .trim(from: 0, to: segmentProgress)
                    .stroke(Color.mint, style: StrokeStyle(lineWidth: 20, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.easeInOut(duration: 0.3), value: segmentProgress)
                    
                VStack(spacing: 8) {
                    Text("\(resistCount)")
                        .font(.system(size: 60, weight: .semibold, design: .rounded))
                        .monospacedDigit()
                        .contentTransition(.numericText())
                        .animation(
                            reduceMotion ? nil : .spring(duration: 0.25),
                            value: resistCount
                        )
                        .accessibilityLabel("Resist count")
                        .accessibilityValue("\(resistCount)")
                    
                    Divider()
                        .frame(width: 80)
                    
                    if let achieved = Milestones.allCases.first(where: { 
                        $0.threshold == resistCount
                    }) {
                        if showCelebration {
                            Text(achieved.congratulatoryMessage)
                                .font(.callout)
                                .frame(width: 200)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 15)
                                .transition(.opacity.combined(with: .scale))
                                .accessibilityFocused($isCelebrationFocused)
                        }
                    } else {
                        Text("Next Goal: \(milestone.next)")
                            .font(.caption)
                    }
                }
            }
            .padding(50)
            .scaleEffect(reduceMotion ? 1.0 : pulse ? 1.04 : 1.0)
            .animation(
                reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.6), 
                value: pulse)
            .onChange(of: resistCount) { _, newValue in
                if let achieved = Milestones.allCases.first(where: {
                    $0.threshold == newValue
                }) {
                    
                    pulse = true
                    showCelebration = true
                    isCelebrationFocused = true
                    
                    if UIAccessibility.isVoiceOverRunning {
                        UIAccessibility.post(
                            notification: .announcement,
                            argument: achieved.congratulatoryMessage
                        )
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                        pulse = false
                        showCelebration = false
                    }
                }
            }
            
            Spacer()
            
            Button("I resisted") {
                resistCount += 1
            }
            .font(.smallCaps(.title2)())
            .padding(.horizontal, 24)
            .padding(.vertical, 14)
            .background(Color.mint)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 50))
            .padding(.bottom, 24)
            .padding()
            .accessibilityLabel("Current Resist Count")
            .accessibilityValue("\(resistCount)")
            .accessibilityHint("Increases the Resist Count by 1")
        }
    }
}

#Preview {
    ResistView()
}

import SwiftUI
import UIKit

struct CalmDownView: View {
    @State private var sessionIsActive = false
    @State private var remainingTime = 60
    @State private var breatheIn = true
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let textChange = Timer.publish(every: 5, on: .main, in: .common).autoconnect()
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        ZStack {
            Color.mint.opacity(0.07)
                .ignoresSafeArea()
            contentStack
        }
    }
    
    private var contentStack: some View {
        VStack {
            Text("\(remainingTime / 60):\(String(format: "%02d", remainingTime % 60))")
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .monospacedDigit()
                .accessibilityLabel("Time remaining")
                .accessibilityValue("\(remainingTime) seconds")
                .contentTransition(.numericText())
                .animation(
                    reduceMotion ? nil : .spring(duration: 0.25),
                    value: remainingTime
                )
                .padding()
            
            ZStack {
                Circle()
                    .shadow(color: .mint, radius: 100)
                    .scaleEffect(sessionIsActive ? 0.8 : 0.3)
                    .animation(
                        reduceMotion ? nil : .easeInOut(duration: 5)
                            .repeatForever(autoreverses: true),
                        value: sessionIsActive
                    )
                    .accessibilityHidden(true)
                
                Circle()
                    .foregroundStyle(.mint)
                    .scaleEffect(sessionIsActive ? 0.9 : 0.6)
                    .animation(
                        reduceMotion ? nil : .easeInOut(duration: 5)
                            .repeatForever(autoreverses: true),
                        value: sessionIsActive
                    )
                    .accessibilityHidden(true)
                    .padding()
                
                
                if !sessionIsActive {
                    VStack {
                        Button("Calm Down") {
                            sessionIsActive = true
                        }
                        .foregroundStyle(.white)
                        .font(.largeTitle.bold())
                        .accessibilityHint("Starts a breathing session")
                        
                        Text("Tap to begin")
                            .foregroundStyle(.white)
                            .font(.caption)
                    }
                } else {
                    Text(breatheIn ? "Breathe In" : "Breathe Out")
                        .font(.title.bold())
                        .foregroundStyle(.white)
                        .onReceive(textChange) { _ in
                            breatheIn.toggle()
                            
                            let announcement = breatheIn ? "Breathe in" : "Breathe out"
                            
                            UIAccessibility.post(
                                notification: .announcement,
                                argument: announcement
                            )
                        }
                        .accessibilityAddTraits(.isHeader)
                }
            }
            .accessibilityElement(children: .contain)
            .accessibilityLabel(sessionIsActive ? "Breathing session active" : "Breathing session not started")
        }
        .onReceive(timer) { _ in
            if sessionIsActive && remainingTime > 0 {
                remainingTime -= 1
            }
            if remainingTime == 0 {
                sessionIsActive = false
                breatheIn = true
                remainingTime = 60
            }
        }
    }
}

#Preview {
    CalmDownView()
}

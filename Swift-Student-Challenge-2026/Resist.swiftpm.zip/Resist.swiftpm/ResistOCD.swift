import SwiftUI

@main
struct ResistOCD: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

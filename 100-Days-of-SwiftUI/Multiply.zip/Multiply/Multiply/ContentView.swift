//
//  ContentView.swift
//  Multiply
//
//  Created by Tarannum on 02/08/26.
//

import SwiftUI

struct ContentView: View {
    @State private var number1 = Int.random(in: 2...12)
    @State private var number2 = Int.random(in: 2...12)
    @State private var playerAnswer: Int? = nil
    @State private var score = 0
    @State private var isShowingGame = false
    @State private var tablesUpTo = 10
    @State private var numberOfRounds = 10
    @State private var roundNumber = 0
    
    var body: some View {
        ZStack {
            if isShowingGame {
                gameView
            } else {
                settingsView
            }
        }
    }
    
    var settingsView: some View {
        VStack {
            Stepper("Tables upto: \(tablesUpTo)", value: $tablesUpTo, in: 2...12)
            Stepper("Number of rounds: \(numberOfRounds)", value: $numberOfRounds, in: 5...20, step: 5)
            Button("Start Game") {
                isShowingGame = true
                nextQuestion()
            }
                .buttonStyle(.borderedProminent)
        }
        .padding()
    }
    
    var gameView: some View {
        VStack {
            Text("Score: \(score)")
            
            Text("\(number1) X \(number2) = ?")
                .font(.largeTitle.bold())
            
            TextField("Type your answer here", value: $playerAnswer, format: .number)
                .multilineTextAlignment(.center)
                .onSubmit(nextQuestion)
                .keyboardType(.numbersAndPunctuation)
        }
        .padding()
    }
    
    func nextQuestion() {
        if number1 * number2 == playerAnswer {
            score += 1
        } else {
            score -= 1
        }
        
        playerAnswer = nil
        
        if score < 0 { score = 0 }
        
        number1 = Int.random(in: 2...tablesUpTo)
        number2 = Int.random(in: 2...12)
        if roundNumber < 10 {
            roundNumber += 1
        } else {
            roundNumber = 0
            isShowingGame = false
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  MultiplyApp.swift
//  Multiply
//
//  Created by Tarannum on 02/08/26.
//

import SwiftUI

@main
struct MultiplyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

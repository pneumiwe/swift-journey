//
//  WordScrambleApp.swift
//  WordScramble
//
//  Created by Tarannum on 25/07/26.
//

import SwiftUI

@main
struct WordScrambleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  BetterRestApp.swift
//  BetterRest
//
//  Created by Tarannum on 11/07/26.
//

import SwiftUI

@main
struct BetterRestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

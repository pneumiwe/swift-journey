//
//  ViewModifierApp.swift
//  ViewModifier
//
//  Created by Tarannum on 04/07/26.
//

import SwiftUI

@main
struct ViewModifierApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  RockPaperScissorsApp.swift
//  RockPaperScissors
//
//  Created by Tarannum on 04/07/26.
//

import SwiftUI

@main
struct RockPaperScissorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  Guess_The_FlagApp.swift
//  Guess The Flag
//
//  Created by Tarannum on 02/07/26.
//

import SwiftUI

@main
struct Guess_The_FlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
